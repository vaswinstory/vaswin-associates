import { Target, Eye, Lightbulb, Shield } from 'lucide-react';

export default function About() {
  const values = [
    {
      icon: Target,
      title: 'Our Mission',
      description:
        'To deliver exceptional construction services that exceed client expectations through innovation, quality craftsmanship, and unwavering commitment to excellence.',
    },
    {
      icon: Eye,
      title: 'Our Vision',
      description:
        'To be the most trusted and respected construction company, setting industry standards for quality, safety, and sustainable building practices.',
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description:
        'We embrace cutting-edge technology and modern construction methods to deliver efficient, sustainable, and future-ready solutions.',
    },
    {
      icon: Shield,
      title: 'Integrity',
      description:
        'Honesty, transparency, and ethical practices form the foundation of every relationship we build with clients, partners, and communities.',
    },
  ];

  const stats = [
    { number: '500+', label: 'Projects Completed' },
    { number: '25+', label: 'Years Experience' },
    { number: '100+', label: 'Expert Team Members' },
    { number: '98%', label: 'Client Satisfaction' },
  ];

  return (
    <div className="min-h-screen pt-20">
      <section className="relative py-20 bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-gray-900 mb-4 animate-fadeIn">About Us</h1>
            <div className="w-24 h-1 bg-orange-500 mx-auto mb-6"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto animate-fadeIn animation-delay-200">
              Building trust, delivering excellence, and creating lasting structures that stand the
              test of time
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Who We Are</h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  VASWIN ASSOCIATES is a premier construction company dedicated to transforming
                  architectural visions into tangible realities. With over two decades of
                  experience, we have established ourselves as industry leaders in residential,
                  commercial, and industrial construction.
                </p>
                <p>
                  Our team of skilled professionals combines traditional craftsmanship with modern
                  innovation, ensuring that every project we undertake meets the highest standards
                  of quality, safety, and sustainability.
                </p>
                <p>
                  From groundbreaking to final inspection, we maintain meticulous attention to
                  detail and open communication with our clients, ensuring their vision is realized
                  beyond expectations.
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-2xl bg-gradient-to-br from-orange-400 to-teal-500 p-1">
                <div className="w-full h-full bg-gray-100 rounded-2xl flex items-center justify-center">
                  <img
                    src="https://images.pexels.com/photos/1216589/pexels-photo-1216589.jpeg?auto=compress&cs=tinysrgb&w=800"
                    alt="Construction team"
                    className="w-full h-full object-cover rounded-2xl"
                  />
                </div>
              </div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-orange-500 rounded-full blur-3xl opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="text-center transform hover:scale-110 transition-transform duration-300"
              >
                <div className="text-4xl lg:text-5xl font-bold text-orange-500 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Values</h2>
            <div className="w-24 h-1 bg-orange-500 mx-auto"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="group p-8 rounded-2xl bg-gray-50 hover:bg-gradient-to-br hover:from-orange-50 hover:to-teal-50 transition-all duration-300 border-2 border-transparent hover:border-orange-200"
              >
                <div className="w-16 h-16 bg-orange-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-orange-500 transition-colors duration-300">
                  <value.icon className="w-8 h-8 text-orange-500 group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
